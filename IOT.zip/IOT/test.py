print("welcome");
